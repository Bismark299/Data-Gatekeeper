import { pgTable, text, serial, timestamp, boolean, integer, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const bundlesTable = pgTable("bundles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  dataAmount: text("data_amount").notNull(),
  validityDays: integer("validity_days").notNull(),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  dealerPrice: numeric("dealer_price", { precision: 10, scale: 2 }),
  agentPrice: numeric("agent_price", { precision: 10, scale: 2 }),
  category: text("category").notNull(),
  network: text("network").notNull().default("mtn"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertBundleSchema = createInsertSchema(bundlesTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertBundle = z.infer<typeof insertBundleSchema>;
export type Bundle = typeof bundlesTable.$inferSelect;
