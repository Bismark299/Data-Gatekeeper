EXISTING MCBIS CODE - SOURCE SNAPSHOT

These are unchanged copies from the current workspace, not proposed replacement code.
The code running on Render may differ if that deployment is not up to date.

Start with artifacts/api-server/src/lib/mcbis.ts:
- API client, headers, balance cache, status request and dispatch functions.
- startMcbisPoller: scheduler, platform/store order checks, guarded database updates,
  store profit crediting, cancellation/refunds and undispatched-order retries.

artifacts/api-server/src/index.ts:
- Existing startup hook that calls startMcbisPoller after schema initialization.

artifacts/api-server/src/lib/refunds.ts:
- Transactional refund/cancellation helpers called by the checker.

artifacts/api-server/src/routes/wallet.ts:
- Existing wallet/ledger helper implementations used by refunds.

lib/db/src/:
- Database initialization and existing schema definitions for reference.

IMPORTANT: This is a source reference bundle, not a standalone runnable app.
It requires the original workspace imports, authentication, schema initialization,
routes, packages and environment configuration. No .env files, API token values,
or database contents are included. Do not run index.ts by itself in another site.

Actual scheduler values override stale source comments:
- First cycle after 5 seconds; interval 10 seconds; overlapping cycles skipped
  within the same process only.
- Up to 30 platform plus 30 store status checks per cycle, 100ms between checks.
- Up to 5 platform plus 5 store dispatch retries per cycle, 500ms between attempts.
- HTTP timeout is 15 seconds. Some comments mention 30-second cycles, 45-second
  timeouts or retry grace periods that do not match the implementation.
- No newly proposed shared queue, cross-process cache, or 403 circuit breaker
  has been added to these copies.
